# laboratorio10
Este es el laboratorio Sesion 10 de IHC
